package com.sri.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.sri.bind.Worker;
import com.sri.service.AdminRegistrationService;


@Controller
public class AccountRegistrationController {
	
	@Autowired
	private AdminRegistrationService service;
	
	@GetMapping(value="/loadForm")
	public String register(Model model) {
		Worker worker=new Worker();
		model.addAttribute("worker",worker);
		return "WorkerRegistration";	
	}
	@PostMapping(value="/register")
	public String handleSubmitBtn(@Valid @ModelAttribute("worker")Worker worker,BindingResult br, Model model) {
		if(br.hasErrors()) {
	    	return "WorkerRegistration";
	    }  
		else {
		boolean isSaved=service.saveWorker(worker);
		model.addAttribute("succmsg","successfully saved!...");
		return "WorkerRegistration";
		}
	}
}
